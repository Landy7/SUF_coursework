package com.example.app16.ui.main;

public class findQuoteVO
{ 
 private String date;

  public findQuoteVO() {}

  public findQuoteVO(String datex)
  {    date = datex;
  }

  public String getdate()
  { return date; }

  public void setdate(String _x)
  { date = _x; }

}


